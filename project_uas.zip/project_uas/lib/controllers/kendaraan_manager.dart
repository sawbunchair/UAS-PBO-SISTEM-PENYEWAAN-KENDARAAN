import '../models/kendaraan.dart';

class KendaraanManager {
  // Menggunakan Collection List untuk menampung objek polimorfisme
  final List<Kendaraan> _daftarKendaraan = [];

  void registrasiKendaraan(Kendaraan kendaraan) {
    _daftarKendaraan.add(kendaraan);
  }

  void logSemuaArmada() {
    if (_daftarKendaraan.isEmpty) {
      print('Belum ada armada kendaraan yang terdaftar.');
      return;
    }
    for (var kndr in _daftarKendaraan) {
      kndr.cetakSpesifikasi(); // Panggilan Polymorphism
    }
  }

  // Higher Order Function .where() untuk melacak plat nomor
  void filterBerdasarkanPlat(String keyword) {
    var pencarian = _daftarKendaraan.where(
      (k) => k.platNomor.toLowerCase().contains(keyword.toLowerCase())
    );

    if (pencarian.isEmpty) {
      print('Tidak ada armada dengan plat nomor "$keyword".');
      return;
    }
    for (var kndr in pencarian) {
      kndr.cetakSpesifikasi();
    }
  }

  // Higher Order Function .fold() untuk menghitung total omzet/nilai aset
  double kalkulasiTotalAset() {
    return _daftarKendaraan.fold(0.0, (total, kndr) => total + kndr.tarifPerHari);
  }

  // Async/Await dengan visualisasi proses logistik rental
  Future<void> sinkronisasiDatabase() async {
    print('\n[Koneksi] Menghubungkan ke server cloud rental...');
    await Future.delayed(Duration(seconds: 2)); // Simulasi delay async
    print('💾 [Backup] Sinkronisasi data armada sukses disalin!');
  }
}