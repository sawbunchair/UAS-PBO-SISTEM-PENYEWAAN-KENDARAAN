import 'kendaraan.dart';

class Mobil extends Kendaraan {
  int jumlahPintu;

  Mobil(String platNomor, double tarifPerHari, this.jumlahPintu) 
      : super(platNomor, tarifPerHari);

  @override
  void cetakSpesifikasi() {
    print('🚗 [Mobil] Plat: $platNomor | Kapasitas: $jumlahPintu Pintu | Tarif: Rp${tarifPerHari.toStringAsFixed(0)}/hari');
  }
}