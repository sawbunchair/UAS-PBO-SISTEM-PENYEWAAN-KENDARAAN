import '../exceptions/sewa_exception.dart';

abstract class Kendaraan {
  // Encapsulation menggunakan field private
  String _platNomor;
  double _tarifPerHari;

  Kendaraan(this._platNomor, this._tarifPerHari) {
    // Validasi input awal pada constructor
    if (_platNomor.trim().isEmpty) throw SewaException('Plat nomor tidak boleh kosong!');
    if (_tarifPerHari <= 0) throw SewaException('Tarif sewa harus lebih besar dari Rp0!');
  }

  // Getter
  String get platNomor => _platNomor;
  double get tarifPerHari => _tarifPerHari;

  // Setter dengan validasi spesifik
  set platNomor(String value) {
    if (value.trim().isEmpty) {
      throw SewaException('Plat nomor tidak boleh dikosongkan!');
    }
    _platNomor = value;
  }

  set tarifPerHari(double value) {
    if (value <= 0) {
      throw SewaException('Tarif baru tidak valid (harus > 0)!');
    }
    _tarifPerHari = value;
  }

  // Method Polymorphism yang wajib di-override oleh subclass
  void cetakSpesifikasi();
}