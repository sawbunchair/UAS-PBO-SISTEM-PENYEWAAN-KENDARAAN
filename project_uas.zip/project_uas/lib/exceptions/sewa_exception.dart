class SewaException implements Exception {
  final String detailPesan;
  SewaException(this.detailPesan);

  @override
  String toString() => 'Kontrol Validasi Sewa: $detailPesan';
}