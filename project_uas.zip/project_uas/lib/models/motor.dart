import 'kendaraan.dart';

class Motor extends Kendaraan {
  String jenisKopling; // Contoh: Matic, Manual, Sport

  Motor(String platNomor, double tarifPerHari, this.jenisKopling) 
      : super(platNomor, tarifPerHari);

  @override
  void cetakSpesifikasi() {
    print('🏍️ [Motor] Plat: $platNomor | Tipe: $jenisKopling | Tarif: Rp${tarifPerHari.toStringAsFixed(0)}/hari');
  }
}